// Get the required elements from the DOM
const signUpButton = document.querySelector('.header-button[value="Sign Up"]');
const signInButton = document.querySelector('.header-button[value="Sign In"]');
const signUpModal = document.querySelector('.signUpModal');
const signInModal = document.querySelector('.signInModal');
const createPostButton = document.querySelector('.post-button[value="Create post"]');
const newPostModal = document.getElementById('newPostModal');

// Function to show the sign up modal
function showSignUpModal() {
  signUpModal.style.display = 'block';
}

// Function to hide the sign up modal
function hideSignUpModal() {
  signUpModal.style.display = 'none';
}

// Function to show the sign in modal
function showSignInModal() {
  signInModal.style.display = 'block';
}

// Function to hide the sign in modal
function hideSignInModal() {
  signInModal.style.display = 'none';
}

// Function to show the create post modal
function showCreatePostModal() {
  newPostModal.style.display = 'block';
}

// Function to hide the create post modal
function hideCreatePostModal() {
  newPostModal.style.display = 'none';
}

// Attach event listeners to the buttons
signUpButton.addEventListener('click', showSignUpModal);
signInButton.addEventListener('click', showSignInModal);
createPostButton.addEventListener('click', showCreatePostModal);

// Close the modals when the close button is clicked
const closeButtons = document.querySelectorAll('.close-btn');
closeButtons.forEach((button) => {
  button.addEventListener('click', () => {
    signUpModal.style.display = 'none';
    signInModal.style.display = 'none';
    newPostModal.style.display = 'none';
  });
});
